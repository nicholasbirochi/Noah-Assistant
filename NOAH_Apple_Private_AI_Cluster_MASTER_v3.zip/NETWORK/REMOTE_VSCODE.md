# VS Code remoto

Fluxo: MacBook VS Code -\> Tailscale -\> SSH -\> host. Use Remote SSH
para executar no ambiente real. Não publicar SSH no roteador. Manter Git
branches, testes e toolchain reproduzíveis.
