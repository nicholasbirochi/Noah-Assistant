# Plano de rede

MacBook: admin. Mini: core server. Studio: compute server. Clientes
comuns: somente API necessária.

SSH apenas de dispositivos administrativos. Studio recebe inferência do
Mini e, quando necessário, do MacBook admin. Sem port forwarding. Usar
nomes privados/MagicDNS quando apropriado.
