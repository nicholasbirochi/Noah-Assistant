# Backlog

P0: auditoria, baseline, tests, settings, LLMProvider (com
`qwen3-coder:30b` como modelo de coding padrão -- ver
`07_MODEL_RUNTIME_STRATEGY.md`; remover o estoque fragmentado de
modelos pequenos 3B-14B que não sustentam o objetivo), policy, safe
tools, API, Tailscale, auth, backup. P1: MLX, streaming/UI, memory/RAG,
voice, launchd, benchmarks (local vs. Claude/Codex nas tarefas reais),
ModelRouter. P2: Studio (só se F14 justificar), split-services,
distributed experiments, routing e otimização.
