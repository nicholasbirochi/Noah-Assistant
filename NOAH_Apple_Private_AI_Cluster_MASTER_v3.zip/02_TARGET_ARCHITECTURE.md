# Arquitetura alvo

``` text
MacBook Air M5 24 GB
VS Code / Git / SSH / Browser
          |
       Tailscale
          |
Mac mini M5 Pro 64 GB  <-- ALVO REAL E IMEDIATO
+----------------------------+
| Noah API / Auth          |
| Agent Core / Policy        |
| Memory / RAG / Embeddings  |
| Tools / Sandbox            |
| Modelo de coding local     |  <-- qwen3-coder:30b (ver 07)
| DB / Logs / Metrics        |
+-------------+--------------+
              |
     (futuro, sem data, opcional)
              |
Mac Studio M5 Max 128 GB
+----------------------------+
| Heavy LLM                  |
| Coding / Reasoning         |
| Larger contexts            |
| Optional distributed work  |
+----------------------------+
```

O sistema tem que funcionar por completo dentro da caixa do Mini. O
Studio é uma extensão hipotética, não uma peça faltante do desenho
atual -- se o retângulo do Studio nunca existir, o Noah ainda cumpre
o objetivo.

Não tratar 64+128 GB como 192 GB de memória uniforme. O ModelRouter
abstrai a topologia.
