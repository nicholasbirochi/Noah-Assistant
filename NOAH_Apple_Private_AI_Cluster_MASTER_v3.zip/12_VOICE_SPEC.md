# Voz

Preservar recursos existentes do Noah. Wake word, STT e TTS devem
ficar atrás de adapters. Preferir execução local. Voice e Web devem usar
o mesmo Agent Core.
