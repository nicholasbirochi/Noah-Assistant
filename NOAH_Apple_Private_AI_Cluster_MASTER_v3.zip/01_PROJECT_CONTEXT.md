# Contexto

O Noah existente é a base; não criar outro produto paralelo. A
plataforma final deve oferecer IA local-first, agentes de coding,
memória/RAG, voz, ferramentas controladas e acesso remoto privado.

Cloud LLM é opcional, explícito e nunca fallback silencioso. O objetivo
econômico é reduzir dependência de cobrança por token, sem prometer
custo zero: hardware, energia, internet, armazenamento e backups
continuam existindo.

## Critério de sucesso da fase atual

Não é "ter um cluster" -- é **conseguir fazer trabalho real de coding
no Mini de 64 GB sem abrir Claude ou Codex**. Se depois de rodar
`BENCHMARKS/PLAN.md` o modelo local ainda não resolve as tarefas reais
que hoje dependem de cloud, o objetivo não foi atingido -- comprar mais
hardware (Studio) só faz sentido depois de provar que o gargalo é
compute/RAM, não o modelo ou o Agent Core.
