# Mini 64 deploy

Atualizar/proteger host; Tailscale/SSH; runtime; Python/toolchain;
clone; secrets; migrations; health/smoke; launchd; backup; benchmark;
reboot test.
