# Cluster benchmark

Mesma versão, modelo/quantização/contexto e tarefas. A: Studio
standalone. B: Mini services + Studio LLM. C: distributed, se suportado.
Registrar ambiente completo e escolher topologia pelo workload, não por
teoria.
