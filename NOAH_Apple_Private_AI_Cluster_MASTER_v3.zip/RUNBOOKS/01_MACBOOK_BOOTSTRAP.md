# MacBook bootstrap

FileVault, updates, Tailscale, VS Code, Git, SSH keys protegidas. Clone
e baseline do Noah. Modelo pequeno para testes. Depois, endpoints são
trocados por config, não reescrita.
