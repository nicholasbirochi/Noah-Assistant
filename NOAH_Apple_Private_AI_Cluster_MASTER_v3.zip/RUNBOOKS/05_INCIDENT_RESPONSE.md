# Incident response

Isolar nó; revogar credenciais; preservar logs; revisar
Git/config/launchd; rotacionar secrets; restaurar backup conhecido
quando necessário; revisar policies; documentar causa e prevenção.
