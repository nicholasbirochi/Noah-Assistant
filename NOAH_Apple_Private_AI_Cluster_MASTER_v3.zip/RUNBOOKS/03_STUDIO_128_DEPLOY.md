# Studio 128 deploy

**Futuro, sem data -- só executar depois de ADR-003 ser revisitada com
métricas reais do Mini.**

Proteger host; Tailscale/SSH; runtime; endpoint privado; baixar modelos
aprovados; registrar no ModelRouter; standalone benchmark;
split-services benchmark; offline/fallback test.
