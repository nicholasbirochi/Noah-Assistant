# Evolução de hardware

## 24 GB (MacBook)

Construir MVP e medir workloads.

## 64 GB (Mac mini M5 Pro) -- alvo atual

Servidor principal; deve suportar todo o core e o modelo de coding
padrão (`qwen3-coder:30b`, ~19 GB em Q4_K_M -- ver
`07_MODEL_RUNTIME_STRATEGY.md`) sem depender de nó nenhum. Real, à
venda desde 09/2026, a partir de US$ 1.699 (config. base). Confirmar
preço/config oficial antes de comprar -- `CHECKLISTS/PRE_PURCHASE.md`.

## 128 GB (Mac Studio) -- futuro, sem data, sem compromisso

Real e disponível (a partir de US$ 2.500, M5 Max), mas **não é a fase
atual**. Só considerar comprar quando:

1. o Mini já estiver rodando o objetivo imediato (F0-F14 concluídas);
2. métricas reais (não achismo) mostrarem gargalo de RAM, contexto,
   qualidade ou throughput que o modelo/config atual no Mini não
   resolve;
3. o custo real (hardware + energia + rede) for comparado, de novo,
   contra simplesmente pagar por API na cloud para os casos raros que
   precisarem de mais poder -- comprar uma segunda máquina de milhares
   de dólares só compensa se o uso justificar, não por padrão.

Validar configuração oficial disponível na data da compra.
