# Phase prompt

Execute SOMENTE `<FASE>` aprovada. Releia architecture/security/ADR;
confira Git e baseline; liste arquivos. Mudança mínima com testes. Sem
cloud obrigatória, refatoração oportunista ou redução de segurança. Ao
final execute testes/lint/typecheck existentes, smoke/benchmark
aplicável, revise diff/secrets/agent artifacts, apresente rollback e
commit técnico. PARE.
