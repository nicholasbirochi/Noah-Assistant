# Studio migration prompt

Adicione o Studio como capacidade opcional. Não mova o core
automaticamente. Primeiro health + standalone benchmark; depois
split-services; por último distributed se suportado. Simule falha do
Studio e prove fallback local no Mini. Não habilite cloud fallback.
