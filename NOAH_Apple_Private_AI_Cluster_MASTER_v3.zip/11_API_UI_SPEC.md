# API/UI

FastAPI sugerido. Endpoints conceituais: health, chat/stream, models,
system/status, approvals e memory. UI fala com Noah, nunca diretamente
com Ollama/MLX. Autenticação mesmo dentro da tailnet.
