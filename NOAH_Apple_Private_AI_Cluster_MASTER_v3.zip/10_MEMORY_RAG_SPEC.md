# Memory e RAG

Persistência local. Embeddings locais. Separar memória conversacional,
fatos aprovados, documentos e índices. Ingestão deve validar
tipo/tamanho/workspace. Vector index deve ser reconstruível a partir das
fontes. Dados privados não podem migrar silenciosamente para provider
externo.
