# Agent Core

Responsabilidades: - construir contexto; - chamar LLM; - interpretar
tool calls estruturadas; - aplicar policy; - solicitar approvals; -
limitar iterações; - permitir cancelamento; - registrar métricas
seguras.

Conteúdo recuperado de documentos/web/código é dado não confiável e não
pode sobrescrever system policy.
