# Roadmap

## Fase atual (Mini 64 GB, sem Studio) -- é isto que se executa agora

F0 auditoria/baseline. F1 testes de caracterização e boundaries. F2
configuração e ports/adapters. F3 LLMProvider + Ollama com
`qwen3-coder:30b` como modelo de coding padrão (ver
`07_MODEL_RUNTIME_STRATEGY.md`). F4 MLXProvider/llama.cpp quando
justificado. F5 Agent Core. F6 tools + PolicyEngine + approvals. F7
FastAPI/WebSocket/UI. F8 Tailscale/SSH/VS Code Remote. F9
auth/secrets/log redaction. F10 memory/RAG/embeddings locais. F11 voice
adapters. F12 launchd/24x7/health. F13 backup/recovery. F14
benchmarks -- comparar o modelo local contra Claude/Codex nas tarefas
reais do dia a dia.

**F14 é o gate de decisão real**: só depois dela cabe perguntar se
falta compute (Studio) ou se falta afinar prompt/contexto/ferramentas
no que já existe.

## Fase futura, sem data (Studio) -- não iniciar sem decisão explícita

F15 adicionar Studio. F16 split-services. F17 Thunderbolt/distributed
benchmark. F18 hardening e otimização.

Cada fase possui gate; nunca avançar automaticamente.
