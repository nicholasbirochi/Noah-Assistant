# Benchmark suite

Tarefas: bug, feature multi-file, testes, refactor, stack trace,
architecture comprehension, tool-use, injection resistance, forbidden
filesystem/network. Métricas: task success, testes, regressões, TTFT,
tokens/s, wall time, RAM, calls, intervenções, diff quality. Salvar
resultados versionáveis sem conteúdo confidencial.
