# Threat Model

Ativos: código, documentos, memória, chaves, tokens, DB e capacidade de
executar comandos. Ameaças: prompt injection, command injection, path
traversal, symlink escape, secret theft, egress/exfiltration, supply
chain, acesso remoto indevido e ações destrutivas. Controles: FileVault,
firewall, Tailscale, least privilege, workspace allowlist, sandbox,
deny-by-default, approvals, egress mínimo, redaction, backups e
verificação de dependências/modelos.
