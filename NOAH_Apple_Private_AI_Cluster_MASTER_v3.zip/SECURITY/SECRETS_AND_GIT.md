# Secrets e Git

Secrets em Keychain/secret store ou ambiente protegido. `.env` real
ignorado; exemplos sem credenciais podem ser versionados. Adicionar
secret scanner ao fluxo. Se um secret for exposto, remover do arquivo
não basta: revogar/rotacionar. Nunca automatizar history rewrite sem
aprovação.
