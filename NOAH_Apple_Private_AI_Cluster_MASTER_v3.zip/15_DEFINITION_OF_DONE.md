# Definition of Done

## Critério primário desta fase

-   **coding do dia a dia no Mini roda sem abrir Claude/Codex** -- os
    outros itens abaixo existem para sustentar este, não o contrário.

## Demais critérios

-   funciona sem API paga;
-   Mini funciona sem Studio;
-   cloud fallback OFF;
-   runtime não público;
-   administração remota privada;
-   auth ativa;
-   secrets fora do Git/logs;
-   tools respeitam policy;
-   RAG/embeddings locais;
-   reboot recupera serviços;
-   backup restaurado em teste;
-   benchmarks registrados (local vs. Claude/Codex nas tarefas reais);
-   Studio pode cair sem derrubar core -- e pode nunca existir.
