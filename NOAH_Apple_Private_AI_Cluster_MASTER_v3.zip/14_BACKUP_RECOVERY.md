# Backup/recovery

Backup criptografado de banco, memória, documentos, config não secreta e
repositórios apropriados. Snapshots antes de migrations. Índices
reconstruíveis. Restore drill obrigatório. Replicar dados entre Mini e
Studio não substitui backup.
