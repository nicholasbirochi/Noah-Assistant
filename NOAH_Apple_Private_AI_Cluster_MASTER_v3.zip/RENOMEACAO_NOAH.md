# Noah

Copia atualizada do plano original. Consulte docs/RENOMEACAO_NOAH.md e .ai/PROJECT_MAP.md no repositorio para o estado implementado e as compatibilidades legadas. O plano descreve objetivos, nao comprova funcionalidades prontas. O ZIP original permanece intacto.
