# ADR-002

Inferência, embeddings, memória e RAG são locais por padrão. Cloud é
opt-in.
