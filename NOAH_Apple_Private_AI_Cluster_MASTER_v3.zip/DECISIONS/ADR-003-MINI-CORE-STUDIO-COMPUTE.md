# ADR-003

Mini mantém core e é, por si só, o alvo completo da fase atual --
inclui o modelo de coding padrão. Studio adiciona compute
adicional **apenas como opção futura sem data**, avaliada de novo (via
`CHECKLISTS/PRE_PURCHASE.md`) depois que o benchmark do Mini sozinho
(F14) mostrar gargalo real. Studio nunca é SPOF nem pré-requisito do
Noah essencial -- se a decisão futura for "não comprar", o sistema
continua completo.
