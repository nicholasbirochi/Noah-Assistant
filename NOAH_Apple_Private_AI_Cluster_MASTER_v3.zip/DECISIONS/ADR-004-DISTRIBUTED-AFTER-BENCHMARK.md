# ADR-004

Inferência distribuída só entra em produção se benchmark real superar
alternativas relevantes.
