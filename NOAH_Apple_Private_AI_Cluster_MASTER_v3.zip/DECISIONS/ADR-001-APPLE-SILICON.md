# ADR-001

Apple Silicon arm64 é a plataforma principal. CUDA/NVIDIA não é
requisito.
