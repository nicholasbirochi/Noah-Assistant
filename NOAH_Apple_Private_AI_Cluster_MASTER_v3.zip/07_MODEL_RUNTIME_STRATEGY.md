# Runtime e modelos

Providers: - Ollama: conveniência. - MLX/MLX-LM: otimização Apple
Silicon. - llama.cpp: interoperabilidade. - OpenAI-compatible local
endpoint: contrato de integração, não cloud obrigatório.

Perfis: fast, general, coding, reasoning, embedding. Nenhum nome de
modelo deve ficar hardcoded no domínio -- o modelo de cada perfil é
config (`NOAH_MODEL_*`), não código, exatamente para poder trocar
sem reescrever nada quando um modelo melhor sair.

## Recomendação inicial pro perfil "coding" (setembro/2026, confirmar antes de baixar)

`qwen3-coder:30b` via Ollama -- 30B total, mixture-of-experts com 3.3B
parâmetros ativos por token, ~19 GB em Q4_K_M, 256K de contexto nativo.
É o modelo que a comunidade converge como melhor custo-benefício de
coding local numa Mac de 64 GB hoje: cabe com folga na memória
unificada (macOS só endereça ~2/3-3/4 da RAM pra GPU, então uma Mac de
64 GB tem de fato ~42-48 GB utilizáveis) deixando espaço real pra
contexto e overhead do agente.

```
ollama pull qwen3-coder:30b
```

Alternativas a considerar no benchmark (`BENCHMARKS/PLAN.md`), não
adotar às cegas: `qwen3-coder-next` (mesma família, variante mais nova
voltada a máquinas de 64 GB), `deepseek-r1:32b`/`deepseek-r1:70b`
(raciocínio, não coding puro).

**Isso é ponto de partida, não decisão final** -- rode o benchmark
suite antes de fixar. Modelos de linguagem evoluem rápido; reconfirme
via `ollama list` na biblioteca oficial antes de qualquer download.

## Sobre a lista de modelos atual (limpeza recomendada)

Os modelos hoje instalados (qwen2.5vl, gemma3, llava, minicpm-v,
qwen2.5:7b, qwen2.5:14b -- todos na faixa 3B-14B, majoritariamente
multimodais/visão) não competem com Claude/Codex em tarefas reais de
coding -- são pequenos demais e voltados a outra coisa (visão, chat
geral). Não faz sentido manter esse conjunto fragmentado se o objetivo
é ter UM modelo de coding forte no perfil "coding". Antes de apagar:
confirmar se algum deles está em uso ativo em outro fluxo do Noah
(ex.: um modelo de visão sendo usado por alguma ferramenta) -- se não
estiver, remover e substituir pelo modelo de coding acima é o passo
concreto mais alinhado com o objetivo desta fase.

Nota à parte: "gemma4:12b" da lista não bate com os tamanhos oficiais
do Gemma 4 (E2B, E4B, 26B MoE, 31B Dense) -- vale conferir se o tag
existe mesmo antes de considerá-lo.
