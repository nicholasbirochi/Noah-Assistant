# Observabilidade

Métricas: TTFT, tokens/s, latência, erros, tool duration, node health,
RAM e fila. Logs estruturados com redaction. Por padrão não persistir
conteúdo integral de prompts privados. Dashboard futuro pode comparar
MacBook/Mini/Studio e modelos.
