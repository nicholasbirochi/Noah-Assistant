# Thunderbolt

USB-C descreve o conector; usar cabo Thunderbolt certificado compatível
com ambos os hosts.

A memória interna é muito mais rápida que a interconexão. Portanto não
usar distribuição apenas para somar capacidades nominais.

Benchmark: - Studio-only; - Mini orchestration + Studio LLM; -
distributed Mini+Studio, quando runtime suportar.

Medir TTFT, tokens/s, wall time, RAM, utilização, tráfego inter-node,
energia aproximada e task success.
