# ModelRouter

Entradas: task profile, privacy class, context estimate, node health e
policy. Saídas: provider, model, node e topology.

Fallback permitido: Studio indisponível -\> modelo LOCAL menor no Mini.
Fallback proibido: Studio indisponível -\> cloud automaticamente.
Health/circuit breaker deve evitar ficar tentando nó indisponível
indefinidamente.
