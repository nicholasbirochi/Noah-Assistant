# Antes de comprar próximo nó

-   [ ] gargalo medido
-   [ ] RAM pico/contexto/tokens-s medidos
-   [ ] workload definido
-   [ ] configuração oficial atual confirmada
-   [ ] rede/cabos/storage considerados
-   [ ] custo energia/storage/backup considerado
-   [ ] compra resolve gargalo real
