# Go-live

-   [ ] FileVault/firewall/updates
-   [ ] Tailscale/SSH privado
-   [ ] sem port forwarding
-   [ ] runtime não público
-   [ ] auth
-   [ ] secrets/log redaction
-   [ ] tool/egress policies
-   [ ] backup/restore
-   [ ] cloud fallback OFF
-   [ ] restart test
