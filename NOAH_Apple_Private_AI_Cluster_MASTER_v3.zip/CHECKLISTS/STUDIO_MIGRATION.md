# Studio migration

**Futuro, sem data. Não usar esta checklist antes de F14 (benchmark do
Mini sozinho) mostrar gargalo real.**

-   [ ] Mini estável
-   [ ] baseline registrado
-   [ ] Studio protegido
-   [ ] endpoint restrito
-   [ ] ModelRouter por config
-   [ ] A/B/C benchmarks
-   [ ] Studio offline test
-   [ ] fallback local Mini
-   [ ] rollback
