# Pre-commit

-   [ ] status/diff staged
-   [ ] testes
-   [ ] secret scan
-   [ ] nenhum `.env` real
-   [ ] nenhum artefato Claude não solicitado
-   [ ] nenhuma assinatura/co-author automática
-   [ ] mensagem técnica
