# Noah Apple Private AI Cluster --- Master Blueprint

Plano mestre para evoluir `nicholasbirochi/Noah-Assistant`.

## Objetivo imediato (é isto que importa agora)

Rodar o Noah localmente no Mac mini M5 Pro 64 GB com capacidade real
de coding, o suficiente para **parar de depender de Claude/Codex
hospedados** no dia a dia de desenvolvimento. Tudo que não serve
diretamente a esse objetivo (Studio, distributed inference, cluster de
3 nós) é trabalho futuro, não a fase atual.

## Topologia

-   MacBook Air M5 --- 24 GB: workstation, VS Code, Git, cliente e
    administração.
-   **Mac mini M5 Pro --- 64 GB: alvo real e imediato.** Servidor
    principal 24/7, roda o modelo de coding e o Agent Core.
-   Mac Studio M5 Max --- 128 GB: **futuro distante, sem data, não
    iniciar sem decisão explícita e sem gargalo medido no Mini
    primeiro.** Ver `DECISIONS/ADR-003`.

## Regra principal

O projeto deve nascer no MacBook, migrar ao Mini sem reescrita. O Mini
sozinho precisa ser suficiente para o objetivo imediato -- o Studio
nunca é pré-requisito.

Leia nesta ordem: 1. `01_PROJECT_CONTEXT.md` 2.
`02_TARGET_ARCHITECTURE.md` 3. `SECURITY/THREAT_MODEL.md` 4.
`SECURITY/CLOUD_AGENT_ZERO_TRACE.md` 5. `03_ROADMAP.md` 6.
`07_MODEL_RUNTIME_STRATEGY.md` 7. `PROMPTS/MASTER_IMPLEMENTATION_PROMPT.md`

Na primeira execução, o coding agent deve apenas auditar e PARAR.
