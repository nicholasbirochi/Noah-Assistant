# Estratégia multi-node

**Modo 1 é o modo atual e único em uso.** Os outros existem só como
referência para quando (e se) o Studio entrar em jogo -- não é a fase
de agora.

Modo 1: Mini standalone -- alvo desta fase. Modo 2: Studio standalone
para LLM pesado (futuro). Modo 3: Mini = orchestration/RAG/tools;
Studio = inferência (futuro). Modo 4: distributed inference, somente
após benchmark (futuro).

Preferência, se e quando o Studio for comprado: Modo 3. Ele evita
gastar bandwidth inter-node em cada camada do modelo e mantém serviços
no Mini.
